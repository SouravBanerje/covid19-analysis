library(shiny)
library(tidyverse)
library(plotly)
library(DT)
library(shinythemes)
library(leaflet)
library(leaflet.extras)

# Load data
covid_data_url <- "https://raw.githubusercontent.com/owid/covid-19-data/master/public/data/owid-covid-data.csv"
covid_data <- read_csv(covid_data_url)

# Load country coordinates data
country_coords_url <- "data/country_coordinates.csv"
country_coords <- read_csv(country_coords_url)

# Clean and prepare data
covid_data_clean <- covid_data %>%
  filter(!is.na(total_cases)) %>%
  mutate(date = as.Date(date))

# Aggregate the latest data for the world map
latest_data <- covid_data_clean %>%
  group_by(location) %>%
  filter(date == max(date)) %>%
  filter(location != "World") %>%
  ungroup() %>%
  left_join(country_coords, by = c("location" = "country"))

# Remove rows with missing or invalid coordinates
latest_data <- latest_data %>%
  filter(!is.na(latitude) & !is.na(longitude) & latitude != 0 & longitude != 0)

# Define UI
ui <- fluidPage(
  theme = shinytheme("cerulean"),
  includeCSS("www/custom.css"),
  titlePanel("COVID-19 Interactive Analysis"),
  sidebarLayout(
    sidebarPanel(
      selectInput("country", "Select Country:", choices = unique(covid_data_clean$location), multiple = TRUE, selected = "World"),
      dateRangeInput("date_range", "Select Date Range:",
                     start = min(covid_data_clean$date),
                     end = max(covid_data_clean$date)),
      actionButton("update", "Update", class = "btn-primary")
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Overview", leafletOutput("world_map")),
        tabPanel("Summary", DTOutput("summary_table")),
        tabPanel("Trends",
                 plotlyOutput("trend_plot_cases"),
                 plotlyOutput("trend_plot_deaths"),
                 plotlyOutput("trend_plot_total_cases"),
                 plotlyOutput("trend_plot_total_deaths"),
                 plotlyOutput("trend_plot_cases_per_million"),
                 plotlyOutput("trend_plot_deaths_per_million")
        ),
        tabPanel("Statistics", verbatimTextOutput("stats_output")),
        tabPanel("Vaccination Data",
                 plotlyOutput("vaccination_trend"),
                 DTOutput("vaccination_table")
        ),
        tabPanel("Comparison",
                 plotlyOutput("comparison_plot_cases"),
                 plotlyOutput("comparison_plot_deaths")
        )
      )
    )
  )
)

# Define server logic
server <- function(input, output) {
  selected_data <- reactive({
    req(input$update)
    covid_data_clean %>%
      filter(location %in% input$country,
             date >= input$date_range[1],
             date <= input$date_range[2])
  })
  
  output$summary_table <- renderDT({
    datatable(selected_data(), options = list(pageLength = 10, scrollX = TRUE))
  })
  
  output$trend_plot_cases <- renderPlotly({
    plot_ly(selected_data(), x = ~date, y = ~new_cases, color = ~location, type = 'scatter', mode = 'lines') %>%
      layout(title = "New Cases Over Time",
             xaxis = list(title = "Date"),
             yaxis = list(title = "New Cases"))
  })
  
  output$trend_plot_deaths <- renderPlotly({
    plot_ly(selected_data(), x = ~date, y = ~new_deaths, color = ~location, type = 'scatter', mode = 'lines') %>%
      layout(title = "New Deaths Over Time",
             xaxis = list(title = "Date"),
             yaxis = list(title = "New Deaths"))
  })
  
  output$trend_plot_total_cases <- renderPlotly({
    plot_ly(selected_data(), x = ~date, y = ~total_cases, color = ~location, type = 'scatter', mode = 'lines') %>%
      layout(title = "Total Cases Over Time",
             xaxis = list(title = "Date"),
             yaxis = list(title = "Total Cases"))
  })
  
  output$trend_plot_total_deaths <- renderPlotly({
    plot_ly(selected_data(), x = ~date, y = ~total_deaths, color = ~location, type = 'scatter', mode = 'lines') %>%
      layout(title = "Total Deaths Over Time",
             xaxis = list(title = "Date"),
             yaxis = list(title = "Total Deaths"))
  })
  
  output$trend_plot_cases_per_million <- renderPlotly({
    plot_ly(selected_data(), x = ~date, y = ~new_cases / population * 1e6, color = ~location, type = 'scatter', mode = 'lines') %>%
      layout(title = "New Cases per Million Over Time",
             xaxis = list(title = "Date"),
             yaxis = list(title = "New Cases per Million"))
  })
  
  output$trend_plot_deaths_per_million <- renderPlotly({
    plot_ly(selected_data(), x = ~date, y = ~new_deaths / population * 1e6, color = ~location, type = 'scatter', mode = 'lines') %>%
      layout(title = "New Deaths per Million Over Time",
             xaxis = list(title = "Date"),
             yaxis = list(title = "New Deaths per Million"))
  })
  
  output$stats_output <- renderPrint({
    data <- selected_data()
    summary_text <- data %>%
      group_by(location) %>%
      summarise(
        Total_Cases = sum(new_cases, na.rm = TRUE),
        Total_Deaths = sum(new_deaths, na.rm = TRUE),
        Start_Date = min(date),
        End_Date = max(date)
      )
    print(summary_text)
  })
  
  output$world_map <- renderLeaflet({
    leaflet() %>%
      addProviderTiles(providers$OpenStreetMap.Mapnik, group = "Standard") %>%
      addProviderTiles(providers$CartoDB.Positron, group = "Light") %>%
      addCircleMarkers(
        data = latest_data,
        ~longitude, ~latitude,
        radius = ~sqrt(total_cases) / 1000,
        color = "red",
        stroke = FALSE, fillOpacity = 0.5,
        popup = ~paste0(
          "Country: ", location,
          " | Total Cases: ", total_cases,
          " | Total Deaths: ", total_deaths
        ),
        label = ~paste0(
          "Country: ", location,
          " | Total Cases: ", total_cases,
          " | Total Deaths: ", total_deaths
        )
      ) %>%
      addLayersControl(
        baseGroups = c("Standard", "Light"),
        options = layersControlOptions(collapsed = FALSE)
      ) %>%
      addLegend(
        position = "bottomright",
        colors = c("red"),
        labels = c("Total Cases"),
        title = "Legend",
        opacity = 0.5
      ) %>%
      setView(lat = 0, lng = 0, zoom = 2)
  })
  
  observeEvent(input$world_map_marker_click, {
    click <- input$world_map_marker_click
    leafletProxy("world_map") %>%
      clearMarkers() %>%
      addCircleMarkers(
        data = latest_data,
        ~longitude, ~latitude,
        radius = ~sqrt(total_cases) / 1000,
        color = ~ifelse(location == click$id, "blue", "red"),
        stroke = FALSE, fillOpacity = 0.5,
        popup = ~paste0(
          "Country: ", location,
          " | Total Cases: ", total_cases,
          " | Total Deaths: ", total_deaths
        ),
        label = ~paste0(
          "Country: ", location,
          " | Total Cases: ", total_cases,
          " | Total Deaths: ", total_deaths
        )
      )
  })
  
  # Vaccination Data
  output$vaccination_trend <- renderPlotly({
    plot_ly(selected_data(), x = ~date, y = ~new_vaccinations, color = ~location, type = 'scatter', mode = 'lines') %>%
      layout(title = "New Vaccinations Over Time",
             xaxis = list(title = "Date"),
             yaxis = list(title = "New Vaccinations"))
  })
  
  output$vaccination_table <- renderDT({
    selected_data() %>%
      select(location, date, new_vaccinations, total_vaccinations) %>%
      datatable(options = list(pageLength = 10, scrollX = TRUE))
  })
  
  # Comparison
  output$comparison_plot_cases <- renderPlotly({
    plot_ly(selected_data(), x = ~date, y = ~new_cases, color = ~location, type = 'scatter', mode = 'lines') %>%
      layout(title = "Comparison of New Cases Over Time",
             xaxis = list(title = "Date"),
             yaxis = list(title = "New Cases"))
  })
  
  output$comparison_plot_deaths <- renderPlotly({
    plot_ly(selected_data(), x = ~date, y = ~new_deaths, color = ~location, type = 'scatter', mode = 'lines') %>%
      layout(title = "Comparison of New Deaths Over Time",
             xaxis = list(title = "Date"),
             yaxis = list(title = "New Deaths"))
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
